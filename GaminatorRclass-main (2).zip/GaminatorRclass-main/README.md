# GaminatorRclass
A thorough R programming course
